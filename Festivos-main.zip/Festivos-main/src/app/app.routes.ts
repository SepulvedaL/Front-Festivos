import { Routes } from '@angular/router';
import { InicioComponent } from './features/componentes/inicio/inicio.component';
import { SeleccionComponent } from './features/componentes/seleccion/seleccion.component';
import { FestivoComponent } from './features/componentes/festivo/festivo.component';


export const routes: Routes = [
    { path: "inicio", component: InicioComponent },
    { path: "festivo", component: FestivoComponent }
];
