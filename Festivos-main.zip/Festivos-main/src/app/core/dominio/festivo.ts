export interface Festivo {
    id: number;
    dia: number;
    mes: number;
    nombre: string;
    tipo : number;
    diaspascua: number;
}