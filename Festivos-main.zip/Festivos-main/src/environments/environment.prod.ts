export const environment = {
    production: true,
    urlBase: ""
}